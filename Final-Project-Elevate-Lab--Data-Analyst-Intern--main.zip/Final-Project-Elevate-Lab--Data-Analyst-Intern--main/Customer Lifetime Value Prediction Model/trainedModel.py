import joblib
joblib.dump(model, "ltv_model.pkl")
